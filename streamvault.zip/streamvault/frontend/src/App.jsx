
import { useState, useEffect, useRef, useCallback, useMemo } from "react";

// ─── Constants ────────────────────────────────────────────────────────────────
const M3U_URL = "https://iptv-org.github.io/iptv/index.m3u";
const CORS_PROXY = "https://corsproxy.io/?";
const LS_FAVS = "iptv_favorites";
const LS_RECENT = "iptv_recent";
const LS_THEME = "iptv_theme";
const MAX_RECENT = 20;

// ─── Helpers ──────────────────────────────────────────────────────────────────
function parseM3U(text) {
  const lines = text.split("\n");
  const channels = [];
  let current = null;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (line.startsWith("#EXTINF:")) {
      const tvgId = line.match(/tvg-id="([^"]*)"/)?.[1] || "";
      const tvgName = line.match(/tvg-name="([^"]*)"/)?.[1] || "";
      const tvgLogo = line.match(/tvg-logo="([^"]*)"/)?.[1] || "";
      const tvgLanguage = line.match(/tvg-language="([^"]*)"/)?.[1] || "";
      const tvgCountry = line.match(/tvg-country="([^"]*)"/)?.[1] || "";
      const groupTitle = line.match(/group-title="([^"]*)"/)?.[1] || "General";
      const nameMatch = line.match(/,(.+)$/);
      const name = nameMatch ? nameMatch[1].trim() : tvgName || "Unknown";
      current = { id: tvgId || `ch_${channels.length}`, name, logo: tvgLogo, language: tvgLanguage, country: tvgCountry, group: groupTitle, url: "", status: "unknown" };
    } else if (line && !line.startsWith("#") && current) {
      current.url = line;
      channels.push(current);
      current = null;
    }
  }
  return channels;
}

function getFromLS(key, fallback) {
  try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; }
}
function setToLS(key, val) {
  try { localStorage.setItem(key, JSON.stringify(val)); } catch {}
}

// ─── Icons ────────────────────────────────────────────────────────────────────
const Icon = ({ name, size = 20, className = "" }) => {
  const icons = {
    tv: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><rect x="2" y="7" width="20" height="15" rx="2" ry="2"/><polyline points="17 2 12 7 7 2"/></svg>,
    search: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>,
    heart: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>,
    heartFill: <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>,
    clock: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>,
    sun: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>,
    moon: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>,
    play: <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" className={className}><polygon points="5 3 19 12 5 21 5 3"/></svg>,
    pause: <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" className={className}><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>,
    expand: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className}><polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/></svg>,
    pip: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className}><rect x="2" y="3" width="20" height="14" rx="2"/><rect x="14" y="11" width="8" height="6" rx="1"/></svg>,
    volume: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className}><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/></svg>,
    mute: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className}><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/></svg>,
    filter: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className}><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/></svg>,
    grid: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className}><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>,
    list: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className}><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>,
    close: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className}><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>,
    refresh: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className}><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>,
    signal: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className}><path d="M1.42 9a16 16 0 0 1 21.16 0"/><path d="M5 12.55a11 11 0 0 1 14.08 0"/><path d="M8.53 16.11a6 6 0 0 1 6.95 0"/><line x1="12" y1="20" x2="12.01" y2="20"/></svg>,
    menu: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className}><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>,
    globe: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className}><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>,
    tag: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className}><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>,
    alert: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className}><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>,
    check: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className}><polyline points="20 6 9 17 4 12"/></svg>,
    dashboard: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className}><rect x="3" y="3" width="7" height="9"/><rect x="14" y="3" width="7" height="5"/><rect x="14" y="12" width="7" height="9"/><rect x="3" y="16" width="7" height="5"/></svg>,
  };
  return icons[name] || null;
};

// ─── HLS Player Hook ──────────────────────────────────────────────────────────
function useHLSPlayer(videoRef, channel) {
  const hlsRef = useRef(null);
  const [playerState, setPlayerState] = useState({ playing: false, error: null, loading: false, buffering: false });

  useEffect(() => {
    if (!channel || !videoRef.current) return;
    const video = videoRef.current;
    setPlayerState(s => ({ ...s, loading: true, error: null }));

    // Cleanup previous
    if (hlsRef.current) { hlsRef.current.destroy(); hlsRef.current = null; }

    const tryNative = () => {
      video.src = channel.url;
      video.load();
      video.play().catch(() => setPlayerState(s => ({ ...s, error: "Playback blocked. Click play.", loading: false })));
    };

    // Check if HLS.js is available (loaded via CDN script)
    if (window.Hls && window.Hls.isSupported() && channel.url.includes(".m3u8")) {
      const hls = new window.Hls({
        enableWorker: true,
        lowLatencyMode: false,
        backBufferLength: 90,
        xhrSetup: (xhr) => { xhr.timeout = 10000; }
      });
      hlsRef.current = hls;
      hls.loadSource(channel.url);
      hls.attachMedia(video);
      hls.on(window.Hls.Events.MANIFEST_PARSED, () => {
        video.play().catch(() => {});
        setPlayerState(s => ({ ...s, loading: false, playing: true }));
      });
      hls.on(window.Hls.Events.ERROR, (_, data) => {
        if (data.fatal) {
          setPlayerState(s => ({ ...s, error: "Stream unavailable or offline.", loading: false, playing: false }));
        }
      });
      hls.on(window.Hls.Events.BUFFER_STALLED_ERROR, () => setPlayerState(s => ({ ...s, buffering: true })));
      hls.on(window.Hls.Events.BUFFER_APPENDED, () => setPlayerState(s => ({ ...s, buffering: false })));
    } else if (video.canPlayType("application/vnd.apple.mpegurl")) {
      tryNative();
    } else {
      tryNative();
    }

    const onPlay = () => setPlayerState(s => ({ ...s, playing: true, loading: false }));
    const onPause = () => setPlayerState(s => ({ ...s, playing: false }));
    const onError = () => setPlayerState(s => ({ ...s, error: "Stream error. Try another channel.", loading: false, playing: false }));
    const onWaiting = () => setPlayerState(s => ({ ...s, buffering: true }));
    const onCanPlay = () => setPlayerState(s => ({ ...s, buffering: false, loading: false }));

    video.addEventListener("play", onPlay);
    video.addEventListener("pause", onPause);
    video.addEventListener("error", onError);
    video.addEventListener("waiting", onWaiting);
    video.addEventListener("canplay", onCanPlay);

    return () => {
      video.removeEventListener("play", onPlay);
      video.removeEventListener("pause", onPause);
      video.removeEventListener("error", onError);
      video.removeEventListener("waiting", onWaiting);
      video.removeEventListener("canplay", onCanPlay);
      if (hlsRef.current) { hlsRef.current.destroy(); hlsRef.current = null; }
    };
  }, [channel?.url]);

  return playerState;
}

// ─── Channel Card ─────────────────────────────────────────────────────────────
function ChannelCard({ channel, isActive, isFav, onSelect, onToggleFav, viewMode }) {
  const statusColor = { live: "#22c55e", offline: "#ef4444", unknown: "#f59e0b" }[channel.status] || "#f59e0b";

  if (viewMode === "list") {
    return (
      <div
        onClick={() => onSelect(channel)}
        style={{
          display: "flex", alignItems: "center", gap: "12px", padding: "10px 14px",
          borderRadius: "10px", cursor: "pointer", transition: "all 0.18s",
          background: isActive ? "var(--accent-dim)" : "var(--card-bg)",
          border: isActive ? "1.5px solid var(--accent)" : "1.5px solid var(--border)",
          marginBottom: "6px"
        }}
      >
        <div style={{ width: "36px", height: "36px", borderRadius: "8px", overflow: "hidden", flexShrink: 0, background: "var(--surface)", display: "flex", alignItems: "center", justifyContent: "center" }}>
          {channel.logo ? <img src={channel.logo} alt="" style={{ width: "100%", height: "100%", objectFit: "contain" }} onError={e => { e.target.style.display = "none"; }} /> : <Icon name="tv" size={18} />}
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontWeight: 600, fontSize: "13px", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", color: "var(--text-primary)" }}>{channel.name}</div>
          <div style={{ fontSize: "11px", color: "var(--text-muted)", display: "flex", gap: "6px", marginTop: "2px" }}>
            {channel.country && <span>{channel.country}</span>}
            {channel.group && <span>· {channel.group.slice(0, 20)}</span>}
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
          <div style={{ width: "7px", height: "7px", borderRadius: "50%", background: statusColor, boxShadow: `0 0 6px ${statusColor}` }} title={channel.status} />
          <button onClick={e => { e.stopPropagation(); onToggleFav(channel); }} style={{ background: "none", border: "none", cursor: "pointer", color: isFav ? "#ef4444" : "var(--text-muted)", padding: "4px", borderRadius: "6px", display: "flex" }}>
            <Icon name={isFav ? "heartFill" : "heart"} size={15} />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div
      onClick={() => onSelect(channel)}
      style={{
        borderRadius: "14px", overflow: "hidden", cursor: "pointer",
        transition: "all 0.22s cubic-bezier(0.34, 1.56, 0.64, 1)",
        transform: isActive ? "scale(1.03)" : "scale(1)",
        background: isActive ? "var(--accent-dim)" : "var(--card-bg)",
        border: isActive ? "2px solid var(--accent)" : "2px solid var(--border)",
        boxShadow: isActive ? "0 8px 32px var(--accent-shadow)" : "0 2px 8px rgba(0,0,0,0.12)",
        position: "relative"
      }}
    >
      <div style={{ height: "90px", background: "var(--surface)", display: "flex", alignItems: "center", justifyContent: "center", position: "relative", overflow: "hidden" }}>
        {channel.logo
          ? <img src={channel.logo} alt={channel.name} style={{ maxWidth: "80%", maxHeight: "70px", objectFit: "contain" }} onError={e => { e.target.style.display = "none"; e.target.nextSibling.style.display = "flex"; }} />
          : null}
        <div style={{ position: channel.logo ? "absolute" : "relative", display: channel.logo ? "none" : "flex", alignItems: "center", justifyContent: "center", width: "100%", height: "100%", color: "var(--text-muted)" }}>
          <Icon name="tv" size={32} />
        </div>
        {isActive && (
          <div style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0.4)", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <div style={{ width: "36px", height: "36px", borderRadius: "50%", background: "var(--accent)", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Icon name="play" size={14} />
            </div>
          </div>
        )}
        <div style={{ position: "absolute", top: "8px", right: "8px", width: "8px", height: "8px", borderRadius: "50%", background: statusColor, boxShadow: `0 0 8px ${statusColor}` }} />
      </div>
      <div style={{ padding: "10px 12px 12px" }}>
        <div style={{ fontWeight: 700, fontSize: "12px", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", color: "var(--text-primary)", marginBottom: "4px" }}>{channel.name}</div>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ fontSize: "10px", color: "var(--text-muted)", display: "flex", gap: "4px", alignItems: "center" }}>
            {channel.country && <span style={{ background: "var(--surface)", padding: "1px 5px", borderRadius: "4px" }}>{channel.country}</span>}
          </div>
          <button onClick={e => { e.stopPropagation(); onToggleFav(channel); }} style={{ background: "none", border: "none", cursor: "pointer", color: isFav ? "#ef4444" : "var(--text-muted)", padding: "2px", borderRadius: "6px", display: "flex" }}>
            <Icon name={isFav ? "heartFill" : "heart"} size={13} />
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Player ───────────────────────────────────────────────────────────────────
function Player({ channel, onClose }) {
  const videoRef = useRef(null);
  const containerRef = useRef(null);
  const { playing, error, loading, buffering } = useHLSPlayer(videoRef, channel);
  const [muted, setMuted] = useState(false);
  const [volume, setVolume] = useState(1);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const hideTimer = useRef(null);

  const togglePlay = () => {
    const v = videoRef.current;
    if (!v) return;
    v.paused ? v.play() : v.pause();
  };

  const toggleMute = () => {
    const v = videoRef.current;
    if (!v) return;
    v.muted = !v.muted;
    setMuted(v.muted);
  };

  const handleVolume = (e) => {
    const v = videoRef.current;
    if (!v) return;
    const val = parseFloat(e.target.value);
    v.volume = val;
    setVolume(val);
    setMuted(val === 0);
    v.muted = val === 0;
  };

  const toggleFullscreen = () => {
    const el = containerRef.current;
    if (!document.fullscreenElement) {
      el.requestFullscreen?.();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen?.();
      setIsFullscreen(false);
    }
  };

  const togglePiP = async () => {
    const v = videoRef.current;
    if (!v) return;
    try {
      if (document.pictureInPictureElement) await document.exitPictureInPicture();
      else await v.requestPictureInPicture();
    } catch {}
  };

  const resetHideTimer = useCallback(() => {
    setShowControls(true);
    clearTimeout(hideTimer.current);
    hideTimer.current = setTimeout(() => setShowControls(false), 3000);
  }, []);

  useEffect(() => {
    resetHideTimer();
    return () => clearTimeout(hideTimer.current);
  }, []);

  if (!channel) return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", background: "var(--player-bg)", borderRadius: "20px", gap: "16px", color: "var(--text-muted)" }}>
      <Icon name="tv" size={64} />
      <div style={{ fontSize: "18px", fontWeight: 600 }}>Select a channel to watch</div>
      <div style={{ fontSize: "13px" }}>Browse thousands of free live TV channels</div>
    </div>
  );

  return (
    <div ref={containerRef} onMouseMove={resetHideTimer} style={{ flex: 1, background: "#000", borderRadius: "20px", overflow: "hidden", position: "relative", minHeight: "300px", display: "flex", flexDirection: "column" }}>
      <video ref={videoRef} style={{ width: "100%", height: "100%", objectFit: "contain", display: "block" }} playsInline />

      {/* Overlay states */}
      {loading && !error && (
        <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", background: "rgba(0,0,0,0.7)", gap: "16px" }}>
          <div style={{ width: "48px", height: "48px", border: "3px solid var(--accent)", borderTopColor: "transparent", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
          <div style={{ color: "#fff", fontSize: "14px" }}>Loading stream...</div>
        </div>
      )}
      {buffering && !loading && (
        <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", background: "rgba(0,0,0,0.4)" }}>
          <div style={{ width: "40px", height: "40px", border: "3px solid rgba(255,255,255,0.3)", borderTopColor: "#fff", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
        </div>
      )}
      {error && (
        <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", background: "rgba(0,0,0,0.85)", gap: "12px" }}>
          <Icon name="alert" size={48} className="" />
          <div style={{ color: "#fff", fontSize: "15px", fontWeight: 600 }}>{error}</div>
          <button onClick={() => window.location.reload()} style={{ background: "var(--accent)", color: "#fff", border: "none", borderRadius: "8px", padding: "8px 20px", cursor: "pointer", fontSize: "13px" }}>Try Again</button>
        </div>
      )}

      {/* Controls overlay */}
      <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", justifyContent: "space-between", opacity: showControls ? 1 : 0, transition: "opacity 0.3s", pointerEvents: showControls ? "auto" : "none" }}>
        {/* Top bar */}
        <div style={{ background: "linear-gradient(to bottom, rgba(0,0,0,0.7), transparent)", padding: "16px 20px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            {channel.logo && <img src={channel.logo} alt="" style={{ height: "28px", objectFit: "contain", borderRadius: "4px" }} onError={e => e.target.style.display = "none"} />}
            <div>
              <div style={{ color: "#fff", fontWeight: 700, fontSize: "15px" }}>{channel.name}</div>
              <div style={{ color: "rgba(255,255,255,0.6)", fontSize: "11px" }}>{channel.group} {channel.country && `· ${channel.country}`}</div>
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: "4px" }}>
            <div style={{ background: "#ef4444", color: "#fff", fontSize: "10px", fontWeight: 700, padding: "3px 8px", borderRadius: "4px", letterSpacing: "1px" }}>● LIVE</div>
          </div>
        </div>

        {/* Bottom controls */}
        <div style={{ background: "linear-gradient(to top, rgba(0,0,0,0.8), transparent)", padding: "16px 20px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
            <button onClick={togglePlay} style={{ background: "rgba(255,255,255,0.15)", border: "none", borderRadius: "50%", width: "40px", height: "40px", cursor: "pointer", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", backdropFilter: "blur(4px)" }}>
              <Icon name={playing ? "pause" : "play"} size={18} />
            </button>
            <button onClick={toggleMute} style={{ background: "none", border: "none", cursor: "pointer", color: "rgba(255,255,255,0.8)", display: "flex" }}>
              <Icon name={muted ? "mute" : "volume"} size={18} />
            </button>
            <input type="range" min="0" max="1" step="0.05" value={muted ? 0 : volume} onChange={handleVolume} style={{ width: "80px", accentColor: "var(--accent)", cursor: "pointer" }} />
            <div style={{ flex: 1 }} />
            <button onClick={togglePiP} style={{ background: "none", border: "none", cursor: "pointer", color: "rgba(255,255,255,0.8)", display: "flex" }} title="Picture in Picture">
              <Icon name="pip" size={18} />
            </button>
            <button onClick={toggleFullscreen} style={{ background: "none", border: "none", cursor: "pointer", color: "rgba(255,255,255,0.8)", display: "flex" }} title="Fullscreen">
              <Icon name="expand" size={18} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Admin Dashboard ──────────────────────────────────────────────────────────
function AdminDashboard({ channels, onClose }) {
  const stats = useMemo(() => {
    const live = channels.filter(c => c.status === "live").length;
    const offline = channels.filter(c => c.status === "offline").length;
    const unknown = channels.filter(c => c.status === "unknown").length;
    const countries = [...new Set(channels.map(c => c.country).filter(Boolean))].length;
    const groups = [...new Set(channels.map(c => c.group).filter(Boolean))].length;
    return { total: channels.length, live, offline, unknown, countries, groups };
  }, [channels]);

  const topCountries = useMemo(() => {
    const map = {};
    channels.forEach(c => { if (c.country) map[c.country] = (map[c.country] || 0) + 1; });
    return Object.entries(map).sort((a, b) => b[1] - a[1]).slice(0, 10);
  }, [channels]);

  const topGroups = useMemo(() => {
    const map = {};
    channels.forEach(c => { if (c.group) map[c.group] = (map[c.group] || 0) + 1; });
    return Object.entries(map).sort((a, b) => b[1] - a[1]).slice(0, 8);
  }, [channels]);

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.85)", backdropFilter: "blur(8px)", zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center", padding: "20px" }}>
      <div style={{ background: "var(--bg)", borderRadius: "20px", width: "min(900px, 100%)", maxHeight: "90vh", overflow: "auto", border: "1px solid var(--border)" }}>
        <div style={{ padding: "24px 28px", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
            <Icon name="dashboard" size={22} />
            <h2 style={{ margin: 0, fontSize: "20px", fontWeight: 700 }}>Admin Dashboard</h2>
          </div>
          <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", color: "var(--text-muted)", display: "flex" }}>
            <Icon name="close" size={22} />
          </button>
        </div>
        <div style={{ padding: "24px 28px" }}>
          {/* Stats Grid */}
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "16px", marginBottom: "28px" }}>
            {[
              { label: "Total Channels", value: stats.total, color: "var(--accent)", icon: "tv" },
              { label: "Live Streams", value: stats.live, color: "#22c55e", icon: "signal" },
              { label: "Offline", value: stats.offline, color: "#ef4444", icon: "alert" },
              { label: "Checking", value: stats.unknown, color: "#f59e0b", icon: "refresh" },
              { label: "Countries", value: stats.countries, color: "#8b5cf6", icon: "globe" },
              { label: "Categories", value: stats.groups, color: "#06b6d4", icon: "tag" },
            ].map(stat => (
              <div key={stat.label} style={{ background: "var(--card-bg)", borderRadius: "14px", padding: "18px 20px", border: "1px solid var(--border)" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "8px" }}>
                  <Icon name={stat.icon} size={16} className="" />
                  <span style={{ fontSize: "12px", color: "var(--text-muted)" }}>{stat.label}</span>
                </div>
                <div style={{ fontSize: "28px", fontWeight: 800, color: stat.color }}>{stat.value.toLocaleString()}</div>
              </div>
            ))}
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px" }}>
            {/* Top Countries */}
            <div style={{ background: "var(--card-bg)", borderRadius: "14px", padding: "18px", border: "1px solid var(--border)" }}>
              <h3 style={{ margin: "0 0 16px", fontSize: "14px", fontWeight: 700, display: "flex", alignItems: "center", gap: "8px" }}>
                <Icon name="globe" size={15} /> Top Countries
              </h3>
              {topCountries.map(([country, count]) => (
                <div key={country} style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "8px" }}>
                  <span style={{ fontSize: "12px", width: "60px", color: "var(--text-primary)" }}>{country || "Unknown"}</span>
                  <div style={{ flex: 1, height: "6px", background: "var(--surface)", borderRadius: "3px", overflow: "hidden" }}>
                    <div style={{ height: "100%", background: "var(--accent)", borderRadius: "3px", width: `${(count / topCountries[0][1]) * 100}%`, transition: "width 0.6s" }} />
                  </div>
                  <span style={{ fontSize: "11px", color: "var(--text-muted)", width: "30px", textAlign: "right" }}>{count}</span>
                </div>
              ))}
            </div>

            {/* Top Categories */}
            <div style={{ background: "var(--card-bg)", borderRadius: "14px", padding: "18px", border: "1px solid var(--border)" }}>
              <h3 style={{ margin: "0 0 16px", fontSize: "14px", fontWeight: 700, display: "flex", alignItems: "center", gap: "8px" }}>
                <Icon name="tag" size={15} /> Top Categories
              </h3>
              {topGroups.map(([group, count]) => (
                <div key={group} style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "8px" }}>
                  <span style={{ fontSize: "12px", flex: 1, color: "var(--text-primary)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{group}</span>
                  <div style={{ width: "80px", height: "6px", background: "var(--surface)", borderRadius: "3px", overflow: "hidden" }}>
                    <div style={{ height: "100%", background: "#8b5cf6", borderRadius: "3px", width: `${(count / topGroups[0][1]) * 100}%` }} />
                  </div>
                  <span style={{ fontSize: "11px", color: "var(--text-muted)", width: "30px", textAlign: "right" }}>{count}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Playlist Info */}
          <div style={{ marginTop: "20px", background: "var(--card-bg)", borderRadius: "14px", padding: "18px", border: "1px solid var(--border)" }}>
            <h3 style={{ margin: "0 0 12px", fontSize: "14px", fontWeight: 700 }}>Playlist Source</h3>
            <div style={{ fontFamily: "monospace", fontSize: "12px", color: "var(--accent)", background: "var(--surface)", padding: "10px 14px", borderRadius: "8px", wordBreak: "break-all" }}>
              {M3U_URL}
            </div>
            <div style={{ marginTop: "10px", fontSize: "12px", color: "var(--text-muted)" }}>
              Source: iptv-org/iptv · Updated: {new Date().toLocaleString()} · Format: M3U Extended
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function IPTVApp() {
  const [theme, setTheme] = useState(() => getFromLS(LS_THEME, "dark"));
  const [channels, setChannels] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(null);
  const [loadProgress, setLoadProgress] = useState(0);
  const [activeChannel, setActiveChannel] = useState(null);
  const [search, setSearch] = useState("");
  const [filterCountry, setFilterCountry] = useState("");
  const [filterGroup, setFilterGroup] = useState("");
  const [filterLanguage, setFilterLanguage] = useState("");
  const [favorites, setFavorites] = useState(() => getFromLS(LS_FAVS, []));
  const [recent, setRecent] = useState(() => getFromLS(LS_RECENT, []));
  const [activeTab, setActiveTab] = useState("all");
  const [viewMode, setViewMode] = useState("grid");
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [showAdmin, setShowAdmin] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);

  // Detect mobile
  useEffect(() => {
    const handler = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener("resize", handler);
    return () => window.removeEventListener("resize", handler);
  }, []);

  // Load HLS.js
  useEffect(() => {
    if (!window.Hls) {
      const s = document.createElement("script");
      s.src = "https://cdn.jsdelivr.net/npm/hls.js@latest/dist/hls.min.js";
      document.head.appendChild(s);
    }
  }, []);

  // Load M3U
  useEffect(() => {
    async function loadPlaylist() {
      setLoading(true);
      setLoadProgress(10);
      try {
        const res = await fetch(CORS_PROXY + encodeURIComponent(M3U_URL));
        setLoadProgress(50);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const text = await res.text();
        setLoadProgress(80);
        const parsed = parseM3U(text);
        setLoadProgress(95);
        // Limit for performance
        const limited = parsed.slice(0, 3000);
        setChannels(limited.map(c => ({ ...c, status: "unknown" })));
        setLoadProgress(100);
        setLoadError(null);
      } catch (e) {
        setLoadError("Failed to load playlist. " + e.message);
      } finally {
        setLoading(false);
      }
    }
    loadPlaylist();
  }, []);

  // Theme CSS vars
  const themeVars = theme === "dark" ? {
    "--bg": "#0a0a0f",
    "--surface": "#13131a",
    "--card-bg": "#16161f",
    "--border": "#1e1e2e",
    "--text-primary": "#e8e8f0",
    "--text-muted": "#6b6b8a",
    "--accent": "#6d5ef5",
    "--accent-dim": "rgba(109,94,245,0.12)",
    "--accent-shadow": "rgba(109,94,245,0.3)",
    "--player-bg": "#0a0a0f",
    "--sidebar-bg": "#0d0d14",
  } : {
    "--bg": "#f0f0f8",
    "--surface": "#ffffff",
    "--card-bg": "#ffffff",
    "--border": "#e0e0ee",
    "--text-primary": "#12121c",
    "--text-muted": "#8888aa",
    "--accent": "#5b4de0",
    "--accent-dim": "rgba(91,77,224,0.08)",
    "--accent-shadow": "rgba(91,77,224,0.2)",
    "--player-bg": "#ffffff",
    "--sidebar-bg": "#f7f7fc",
  };

  const toggleTheme = () => {
    const next = theme === "dark" ? "light" : "dark";
    setTheme(next);
    setToLS(LS_THEME, next);
  };

  const selectChannel = useCallback((channel) => {
    setActiveChannel(channel);
    setRecent(prev => {
      const next = [channel, ...prev.filter(c => c.id !== channel.id)].slice(0, MAX_RECENT);
      setToLS(LS_RECENT, next);
      return next;
    });
    if (isMobile) setSidebarOpen(false);
  }, [isMobile]);

  const toggleFav = useCallback((channel) => {
    setFavorites(prev => {
      const exists = prev.some(c => c.id === channel.id);
      const next = exists ? prev.filter(c => c.id !== channel.id) : [channel, ...prev];
      setToLS(LS_FAVS, next);
      return next;
    });
  }, []);

  const favIds = useMemo(() => new Set(favorites.map(c => c.id)), [favorites]);

  // Filter options
  const countries = useMemo(() => [...new Set(channels.map(c => c.country).filter(Boolean))].sort(), [channels]);
  const groups = useMemo(() => [...new Set(channels.map(c => c.group).filter(Boolean))].sort(), [channels]);
  const languages = useMemo(() => [...new Set(channels.map(c => c.language).filter(Boolean))].sort(), [channels]);

  // Filtered channels
  const filteredChannels = useMemo(() => {
    let list = channels;
    if (activeTab === "favorites") list = favorites;
    else if (activeTab === "recent") list = recent;
    if (search) list = list.filter(c => c.name.toLowerCase().includes(search.toLowerCase()));
    if (filterCountry) list = list.filter(c => c.country === filterCountry);
    if (filterGroup) list = list.filter(c => c.group === filterGroup);
    if (filterLanguage) list = list.filter(c => c.language === filterLanguage);
    return list.slice(0, 500);
  }, [channels, activeTab, favorites, recent, search, filterCountry, filterGroup, filterLanguage]);

  const hasFilters = filterCountry || filterGroup || filterLanguage || search;

  const clearFilters = () => {
    setSearch("");
    setFilterCountry("");
    setFilterGroup("");
    setFilterLanguage("");
  };

  return (
    <div style={{ ...themeVars, minHeight: "100vh", background: "var(--bg)", color: "var(--text-primary)", fontFamily: "'DM Sans', 'Segoe UI', system-ui, sans-serif", display: "flex", flexDirection: "column" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        ::-webkit-scrollbar { width: 5px; height: 5px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; } }
        input[type=range] { -webkit-appearance: none; height: 3px; border-radius: 2px; background: rgba(255,255,255,0.2); }
        input[type=range]::-webkit-slider-thumb { -webkit-appearance: none; width: 12px; height: 12px; border-radius: 50%; background: #fff; cursor: pointer; }
        select { appearance: none; background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%23888' stroke-width='2'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E"); background-repeat: no-repeat; background-position: right 10px center; padding-right: 28px !important; }
        button:hover { opacity: 0.85; }
      `}</style>

      {/* Header */}
      <header style={{ background: "var(--surface)", borderBottom: "1px solid var(--border)", padding: "0 20px", height: "58px", display: "flex", alignItems: "center", gap: "12px", position: "sticky", top: 0, zIndex: 100, backdropFilter: "blur(12px)" }}>
        <button onClick={() => setSidebarOpen(s => !s)} style={{ background: "none", border: "none", cursor: "pointer", color: "var(--text-muted)", display: "flex", padding: "6px" }}>
          <Icon name="menu" size={20} />
        </button>
        <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
          <div style={{ width: "30px", height: "30px", background: "var(--accent)", borderRadius: "8px", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Icon name="tv" size={16} />
          </div>
          <span style={{ fontWeight: 800, fontSize: "17px", letterSpacing: "-0.3px" }}>StreamVault</span>
        </div>

        {/* Search bar */}
        <div style={{ flex: 1, maxWidth: "420px", position: "relative", marginLeft: "8px" }}>
          <div style={{ position: "absolute", left: "12px", top: "50%", transform: "translateY(-50%)", color: "var(--text-muted)", pointerEvents: "none" }}>
            <Icon name="search" size={15} />
          </div>
          <input
            type="text"
            value={search}
            onChange={e => { setSearch(e.target.value); setActiveTab("all"); }}
            placeholder="Search channels..."
            style={{ width: "100%", background: "var(--card-bg)", border: "1px solid var(--border)", borderRadius: "10px", padding: "8px 12px 8px 36px", fontSize: "13px", color: "var(--text-primary)", outline: "none" }}
          />
          {search && <button onClick={() => setSearch("")} style={{ position: "absolute", right: "10px", top: "50%", transform: "translateY(-50%)", background: "none", border: "none", cursor: "pointer", color: "var(--text-muted)", display: "flex" }}><Icon name="close" size={14} /></button>}
        </div>

        <div style={{ flex: 1 }} />

        {/* Actions */}
        <button onClick={() => setShowAdmin(true)} style={{ background: "var(--card-bg)", border: "1px solid var(--border)", borderRadius: "8px", padding: "6px 12px", cursor: "pointer", color: "var(--text-muted)", display: "flex", alignItems: "center", gap: "6px", fontSize: "12px" }}>
          <Icon name="dashboard" size={15} /> {!isMobile && "Admin"}
        </button>
        <button onClick={toggleTheme} style={{ background: "var(--card-bg)", border: "1px solid var(--border)", borderRadius: "8px", padding: "7px", cursor: "pointer", color: "var(--text-muted)", display: "flex" }}>
          <Icon name={theme === "dark" ? "sun" : "moon"} size={17} />
        </button>
      </header>

      {/* Body */}
      <div style={{ flex: 1, display: "flex", overflow: "hidden", height: "calc(100vh - 58px)" }}>
        {/* Sidebar */}
        {sidebarOpen && (
          <aside style={{ width: isMobile ? "100%" : "340px", background: "var(--sidebar-bg)", borderRight: "1px solid var(--border)", display: "flex", flexDirection: "column", overflow: "hidden", position: isMobile ? "absolute" : "relative", inset: isMobile ? 0 : "auto", zIndex: isMobile ? 50 : "auto", top: isMobile ? 0 : "auto", animation: "fadeIn 0.2s ease" }}>
            {/* Tabs */}
            <div style={{ padding: "14px 16px 0", display: "flex", gap: "6px" }}>
              {[["all", "tv", "All"], ["favorites", "heartFill", "Fav"], ["recent", "clock", "Recent"]].map(([tab, icon, label]) => (
                <button key={tab} onClick={() => setActiveTab(tab)} style={{ flex: 1, background: activeTab === tab ? "var(--accent)" : "var(--card-bg)", color: activeTab === tab ? "#fff" : "var(--text-muted)", border: "1px solid", borderColor: activeTab === tab ? "var(--accent)" : "var(--border)", borderRadius: "8px", padding: "7px 6px", cursor: "pointer", fontSize: "11px", fontWeight: 600, display: "flex", alignItems: "center", justifyContent: "center", gap: "5px" }}>
                  <Icon name={icon} size={13} />{label}
                </button>
              ))}
            </div>

            {/* Filters */}
            <div style={{ padding: "12px 16px", display: "flex", flexDirection: "column", gap: "8px" }}>
              {[
                ["Country", filterCountry, setFilterCountry, countries],
                ["Category", filterGroup, setFilterGroup, groups.slice(0, 100)],
                ["Language", filterLanguage, setFilterLanguage, languages],
              ].map(([label, val, setter, opts]) => (
                <select key={label} value={val} onChange={e => setter(e.target.value)} style={{ background: "var(--card-bg)", border: "1px solid var(--border)", borderRadius: "8px", padding: "7px 28px 7px 10px", fontSize: "12px", color: val ? "var(--text-primary)" : "var(--text-muted)", cursor: "pointer", width: "100%", outline: "none" }}>
                  <option value="">All {label}s</option>
                  {opts.map(o => <option key={o} value={o}>{o}</option>)}
                </select>
              ))}
              {hasFilters && (
                <button onClick={clearFilters} style={{ background: "var(--accent-dim)", border: "1px solid var(--accent)", borderRadius: "8px", padding: "6px", cursor: "pointer", color: "var(--accent)", fontSize: "11px", fontWeight: 600, display: "flex", alignItems: "center", justifyContent: "center", gap: "6px" }}>
                  <Icon name="close" size={12} /> Clear Filters
                </button>
              )}
            </div>

            {/* Channel count + view toggle */}
            <div style={{ padding: "0 16px 10px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <span style={{ fontSize: "11px", color: "var(--text-muted)" }}>{filteredChannels.length.toLocaleString()} channels</span>
              <div style={{ display: "flex", gap: "4px" }}>
                {[["grid", "grid"], ["list", "list"]].map(([mode, icon]) => (
                  <button key={mode} onClick={() => setViewMode(mode)} style={{ background: viewMode === mode ? "var(--accent)" : "var(--card-bg)", color: viewMode === mode ? "#fff" : "var(--text-muted)", border: "1px solid var(--border)", borderRadius: "6px", padding: "5px", cursor: "pointer", display: "flex" }}>
                    <Icon name={icon} size={13} />
                  </button>
                ))}
              </div>
            </div>

            {/* Channel List */}
            <div style={{ flex: 1, overflowY: "auto", padding: viewMode === "grid" ? "0 12px 12px" : "0 10px 12px" }}>
              {loading ? (
                <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "200px", gap: "16px" }}>
                  <div style={{ position: "relative", width: "60px", height: "60px" }}>
                    <div style={{ position: "absolute", inset: 0, border: "3px solid var(--border)", borderRadius: "50%" }} />
                    <div style={{ position: "absolute", inset: 0, border: "3px solid var(--accent)", borderTopColor: "transparent", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
                  </div>
                  <div style={{ fontSize: "13px", color: "var(--text-muted)" }}>Loading {loadProgress}%</div>
                  <div style={{ width: "140px", height: "4px", background: "var(--border)", borderRadius: "2px", overflow: "hidden" }}>
                    <div style={{ width: `${loadProgress}%`, height: "100%", background: "var(--accent)", transition: "width 0.3s", borderRadius: "2px" }} />
                  </div>
                </div>
              ) : loadError ? (
                <div style={{ padding: "20px", textAlign: "center", color: "var(--text-muted)" }}>
                  <Icon name="alert" size={32} />
                  <div style={{ marginTop: "10px", fontSize: "13px" }}>{loadError}</div>
                </div>
              ) : filteredChannels.length === 0 ? (
                <div style={{ padding: "40px 20px", textAlign: "center", color: "var(--text-muted)" }}>
                  <Icon name="search" size={32} />
                  <div style={{ marginTop: "10px", fontSize: "13px" }}>No channels found</div>
                  {hasFilters && <button onClick={clearFilters} style={{ marginTop: "10px", background: "none", border: "none", cursor: "pointer", color: "var(--accent)", fontSize: "12px" }}>Clear filters</button>}
                </div>
              ) : viewMode === "grid" ? (
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px" }}>
                  {filteredChannels.map(ch => (
                    <ChannelCard key={ch.id} channel={ch} isActive={activeChannel?.id === ch.id} isFav={favIds.has(ch.id)} onSelect={selectChannel} onToggleFav={toggleFav} viewMode="grid" />
                  ))}
                </div>
              ) : (
                <div>
                  {filteredChannels.map(ch => (
                    <ChannelCard key={ch.id} channel={ch} isActive={activeChannel?.id === ch.id} isFav={favIds.has(ch.id)} onSelect={selectChannel} onToggleFav={toggleFav} viewMode="list" />
                  ))}
                </div>
              )}
            </div>
          </aside>
        )}

        {/* Main player area */}
        <main style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", padding: isMobile ? "12px" : "20px", gap: "16px" }}>
          <Player channel={activeChannel} />

          {/* Channel info strip */}
          {activeChannel && (
            <div style={{ background: "var(--card-bg)", borderRadius: "14px", padding: "14px 20px", border: "1px solid var(--border)", display: "flex", alignItems: "center", gap: "16px", animation: "fadeIn 0.3s ease" }}>
              {activeChannel.logo && (
                <img src={activeChannel.logo} alt="" style={{ height: "40px", maxWidth: "80px", objectFit: "contain", borderRadius: "6px" }} onError={e => e.target.style.display = "none"} />
              )}
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 800, fontSize: "16px", marginBottom: "4px" }}>{activeChannel.name}</div>
                <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
                  {activeChannel.country && <span style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: "6px", padding: "2px 8px", fontSize: "11px", color: "var(--text-muted)", display: "flex", alignItems: "center", gap: "4px" }}><Icon name="globe" size={11} />{activeChannel.country}</span>}
                  {activeChannel.group && <span style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: "6px", padding: "2px 8px", fontSize: "11px", color: "var(--text-muted)", display: "flex", alignItems: "center", gap: "4px" }}><Icon name="tag" size={11} />{activeChannel.group}</span>}
                  {activeChannel.language && <span style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: "6px", padding: "2px 8px", fontSize: "11px", color: "var(--text-muted)" }}>{activeChannel.language}</span>}
                </div>
              </div>
              <button onClick={() => toggleFav(activeChannel)} style={{ background: favIds.has(activeChannel.id) ? "rgba(239,68,68,0.12)" : "var(--surface)", border: "1px solid", borderColor: favIds.has(activeChannel.id) ? "#ef4444" : "var(--border)", borderRadius: "10px", padding: "8px 16px", cursor: "pointer", color: favIds.has(activeChannel.id) ? "#ef4444" : "var(--text-muted)", display: "flex", alignItems: "center", gap: "6px", fontSize: "12px", fontWeight: 600 }}>
                <Icon name={favIds.has(activeChannel.id) ? "heartFill" : "heart"} size={15} />
                {favIds.has(activeChannel.id) ? "Saved" : "Save"}
              </button>
            </div>
          )}

          {/* Recently watched (when no channel playing) */}
          {!activeChannel && recent.length > 0 && (
            <div style={{ animation: "fadeIn 0.3s ease" }}>
              <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "12px" }}>
                <Icon name="clock" size={16} />
                <h3 style={{ fontSize: "14px", fontWeight: 700 }}>Recently Watched</h3>
              </div>
              <div style={{ display: "flex", gap: "10px", overflowX: "auto", paddingBottom: "8px" }}>
                {recent.slice(0, 8).map(ch => (
                  <div key={ch.id} onClick={() => selectChannel(ch)} style={{ flexShrink: 0, width: "110px", cursor: "pointer", textAlign: "center" }}>
                    <div style={{ width: "110px", height: "70px", background: "var(--card-bg)", borderRadius: "10px", display: "flex", alignItems: "center", justifyContent: "center", border: "1px solid var(--border)", marginBottom: "6px", overflow: "hidden", transition: "all 0.2s", position: "relative" }}>
                      {ch.logo ? <img src={ch.logo} alt={ch.name} style={{ maxWidth: "80%", maxHeight: "55px", objectFit: "contain" }} onError={e => e.target.style.display = "none"} /> : <Icon name="tv" size={24} />}
                      <div style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0)", display: "flex", alignItems: "center", justifyContent: "center", transition: "background 0.2s" }} className="play-overlay">
                      </div>
                    </div>
                    <div style={{ fontSize: "11px", fontWeight: 600, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", color: "var(--text-primary)" }}>{ch.name}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </main>
      </div>

      {showAdmin && <AdminDashboard channels={channels} onClose={() => setShowAdmin(false)} />}
    </div>
  );
}
