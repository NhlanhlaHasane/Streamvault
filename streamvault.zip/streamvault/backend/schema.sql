-- ─────────────────────────────────────────────────────────────────────────────
-- StreamVault — PostgreSQL Database Schema
-- Run: psql -d streamvault -f schema.sql
-- ─────────────────────────────────────────────────────────────────────────────

-- Extension for UUID generation
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm"; -- for fast full-text search

-- ─── Users ────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email         VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255),
  name          VARCHAR(100),
  avatar_url    TEXT,
  role          VARCHAR(20) DEFAULT 'user' CHECK (role IN ('user', 'admin')),
  google_id     VARCHAR(100),
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  updated_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_google_id ON users(google_id);

-- ─── Channels ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS channels (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tvg_id        VARCHAR(255),
  name          VARCHAR(500) NOT NULL,
  logo_url      TEXT,
  language      VARCHAR(100),
  country       VARCHAR(10),
  group_title   VARCHAR(255),
  stream_url    TEXT UNIQUE NOT NULL,
  epg_url       TEXT,
  resolution    VARCHAR(20),
  status        VARCHAR(20) DEFAULT 'unknown' CHECK (status IN ('live', 'offline', 'unknown')),
  last_checked  TIMESTAMPTZ,
  check_count   INTEGER DEFAULT 0,
  live_count    INTEGER DEFAULT 0,
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  updated_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_channels_name_trgm ON channels USING GIN(name gin_trgm_ops);
CREATE INDEX idx_channels_country ON channels(country);
CREATE INDEX idx_channels_group ON channels(group_title);
CREATE INDEX idx_channels_language ON channels(language);
CREATE INDEX idx_channels_status ON channels(status);
CREATE INDEX idx_channels_last_checked ON channels(last_checked);

-- ─── Favorites ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS favorites (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  channel_id  UUID NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (user_id, channel_id)
);

CREATE INDEX idx_favorites_user ON favorites(user_id);

-- ─── Recently Watched ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS recently_watched (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  channel_id  UUID NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  watched_at  TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (user_id, channel_id)
);

CREATE INDEX idx_recent_user_time ON recently_watched(user_id, watched_at DESC);

-- ─── EPG Data ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS epg_programs (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  channel_id  UUID NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  title       VARCHAR(500) NOT NULL,
  description TEXT,
  start_time  TIMESTAMPTZ NOT NULL,
  end_time    TIMESTAMPTZ NOT NULL,
  category    VARCHAR(100),
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_epg_channel_time ON epg_programs(channel_id, start_time, end_time);

-- ─── Playlist Updates (audit log) ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS playlist_updates (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  channel_count INTEGER,
  inserted      INTEGER,
  updated       INTEGER,
  duration_ms   INTEGER,
  error         TEXT,
  updated_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Stream Health Log ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS stream_health_log (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  channel_id  UUID NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  status      VARCHAR(20) NOT NULL,
  response_ms INTEGER,
  checked_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_health_channel_time ON stream_health_log(channel_id, checked_at DESC);

-- ─── User Sessions ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS user_sessions (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash  VARCHAR(255) NOT NULL,
  expires_at  TIMESTAMPTZ NOT NULL,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_sessions_user ON user_sessions(user_id);
CREATE INDEX idx_sessions_token ON user_sessions(token_hash);

-- ─── Helpful Views ────────────────────────────────────────────────────────────
CREATE OR REPLACE VIEW v_channel_stats AS
SELECT
  COUNT(*) AS total,
  COUNT(*) FILTER (WHERE status = 'live') AS live,
  COUNT(*) FILTER (WHERE status = 'offline') AS offline,
  COUNT(*) FILTER (WHERE status = 'unknown') AS unknown,
  COUNT(DISTINCT country) AS countries,
  COUNT(DISTINCT group_title) AS categories,
  COUNT(DISTINCT language) AS languages
FROM channels;

CREATE OR REPLACE VIEW v_top_countries AS
SELECT country, COUNT(*) AS channel_count
FROM channels WHERE country IS NOT NULL
GROUP BY country ORDER BY channel_count DESC LIMIT 30;

CREATE OR REPLACE VIEW v_top_categories AS
SELECT group_title, COUNT(*) AS channel_count
FROM channels WHERE group_title IS NOT NULL
GROUP BY group_title ORDER BY channel_count DESC LIMIT 30;

-- ─── Seed admin user (change password!) ──────────────────────────────────────
-- Password: admin123 (bcrypt hash — CHANGE BEFORE PRODUCTION)
INSERT INTO users (email, password_hash, name, role)
VALUES (
  'admin@streamvault.tv',
  '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBAi9G2RGBnwei',
  'Admin',
  'admin'
) ON CONFLICT DO NOTHING;

-- ─── Update trigger for updated_at ───────────────────────────────────────────
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_users_updated BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_channels_updated BEFORE UPDATE ON channels FOR EACH ROW EXECUTE FUNCTION update_updated_at();
