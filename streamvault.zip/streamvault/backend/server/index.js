// ─────────────────────────────────────────────────────────────────────────────
// StreamVault Backend — server/index.js
// Node.js + Express + PostgreSQL + Caching + M3U Refresh
// ─────────────────────────────────────────────────────────────────────────────

const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const { Pool } = require("pg");
const axios = require("axios");
const cron = require("node-cron");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const NodeCache = require("node-cache");
const { parseM3U, checkStreamHealth } = require("./utils/playlist");
require("dotenv").config();

const app = express();
const cache = new NodeCache({ stdTTL: 600, checkperiod: 120 });

// ─── Database ─────────────────────────────────────────────────────────────────
const db = new Pool({
  host: process.env.PG_HOST || "localhost",
  port: parseInt(process.env.PG_PORT || "5432"),
  database: process.env.PG_DATABASE || "streamvault",
  user: process.env.PG_USER || "postgres",
  password: process.env.PG_PASSWORD,
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
});

// ─── Middleware ────────────────────────────────────────────────────────────────
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.FRONTEND_URL || "http://localhost:3000", credentials: true }));
app.use(express.json({ limit: "10mb" }));

const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 200 });
app.use("/api/", limiter);

// ─── Auth Middleware ──────────────────────────────────────────────────────────
const authMiddleware = (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).json({ error: "No token" });
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET || "secret");
    next();
  } catch {
    res.status(401).json({ error: "Invalid token" });
  }
};

const adminMiddleware = (req, res, next) => {
  authMiddleware(req, res, () => {
    if (req.user.role !== "admin") return res.status(403).json({ error: "Forbidden" });
    next();
  });
};

// ─────────────────────────────────────────────────────────────────────────────
// PUBLIC ROUTES
// ─────────────────────────────────────────────────────────────────────────────

// GET /api/channels — with pagination, search, filter
app.get("/api/channels", async (req, res) => {
  const {
    search = "", country = "", group = "", language = "",
    page = 1, limit = 100, status = ""
  } = req.query;

  const cacheKey = `channels:${JSON.stringify(req.query)}`;
  const cached = cache.get(cacheKey);
  if (cached) return res.json(cached);

  try {
    const offset = (parseInt(page) - 1) * parseInt(limit);
    let where = ["1=1"];
    const params = [];

    if (search) { params.push(`%${search.toLowerCase()}%`); where.push(`LOWER(name) LIKE $${params.length}`); }
    if (country) { params.push(country); where.push(`country = $${params.length}`); }
    if (group) { params.push(group); where.push(`group_title = $${params.length}`); }
    if (language) { params.push(language); where.push(`language = $${params.length}`); }
    if (status) { params.push(status); where.push(`status = $${params.length}`); }

    const whereStr = where.join(" AND ");

    const [rows, countRow] = await Promise.all([
      db.query(`SELECT * FROM channels WHERE ${whereStr} ORDER BY name LIMIT $${params.length + 1} OFFSET $${params.length + 2}`, [...params, limit, offset]),
      db.query(`SELECT COUNT(*) FROM channels WHERE ${whereStr}`, params)
    ]);

    const result = {
      channels: rows.rows,
      total: parseInt(countRow.rows[0].count),
      page: parseInt(page),
      pages: Math.ceil(parseInt(countRow.rows[0].count) / parseInt(limit))
    };

    cache.set(cacheKey, result, 300);
    res.json(result);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Database error" });
  }
});

// GET /api/channels/:id
app.get("/api/channels/:id", async (req, res) => {
  try {
    const { rows } = await db.query("SELECT * FROM channels WHERE id = $1", [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: "Not found" });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/countries
app.get("/api/countries", async (req, res) => {
  const cached = cache.get("countries");
  if (cached) return res.json(cached);
  try {
    const { rows } = await db.query("SELECT country, COUNT(*) as count FROM channels WHERE country IS NOT NULL GROUP BY country ORDER BY count DESC");
    cache.set("countries", rows, 3600);
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET /api/groups
app.get("/api/groups", async (req, res) => {
  const cached = cache.get("groups");
  if (cached) return res.json(cached);
  try {
    const { rows } = await db.query("SELECT group_title, COUNT(*) as count FROM channels WHERE group_title IS NOT NULL GROUP BY group_title ORDER BY count DESC");
    cache.set("groups", rows, 3600);
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET /api/languages
app.get("/api/languages", async (req, res) => {
  const cached = cache.get("languages");
  if (cached) return res.json(cached);
  try {
    const { rows } = await db.query("SELECT language, COUNT(*) as count FROM channels WHERE language IS NOT NULL GROUP BY language ORDER BY count DESC");
    cache.set("languages", rows, 3600);
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET /api/stats — public stats for admin dashboard
app.get("/api/stats", async (req, res) => {
  const cached = cache.get("stats");
  if (cached) return res.json(cached);
  try {
    const [total, live, offline, countries, groups, lastUpdate] = await Promise.all([
      db.query("SELECT COUNT(*) FROM channels"),
      db.query("SELECT COUNT(*) FROM channels WHERE status = 'live'"),
      db.query("SELECT COUNT(*) FROM channels WHERE status = 'offline'"),
      db.query("SELECT COUNT(DISTINCT country) FROM channels WHERE country IS NOT NULL"),
      db.query("SELECT COUNT(DISTINCT group_title) FROM channels WHERE group_title IS NOT NULL"),
      db.query("SELECT updated_at FROM playlist_updates ORDER BY updated_at DESC LIMIT 1"),
    ]);
    const stats = {
      total: parseInt(total.rows[0].count),
      live: parseInt(live.rows[0].count),
      offline: parseInt(offline.rows[0].count),
      unknown: parseInt(total.rows[0].count) - parseInt(live.rows[0].count) - parseInt(offline.rows[0].count),
      countries: parseInt(countries.rows[0].count),
      groups: parseInt(groups.rows[0].count),
      lastUpdate: lastUpdate.rows[0]?.updated_at || null,
    };
    cache.set("stats", stats, 120);
    res.json(stats);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ─────────────────────────────────────────────────────────────────────────────
// AUTH ROUTES
// ─────────────────────────────────────────────────────────────────────────────

// POST /api/auth/register
app.post("/api/auth/register", async (req, res) => {
  const { email, password, name } = req.body;
  if (!email || !password) return res.status(400).json({ error: "Email and password required" });
  try {
    const exists = await db.query("SELECT id FROM users WHERE email = $1", [email]);
    if (exists.rows.length) return res.status(409).json({ error: "Email already registered" });
    const hash = await bcrypt.hash(password, 12);
    const { rows } = await db.query(
      "INSERT INTO users (email, password_hash, name) VALUES ($1, $2, $3) RETURNING id, email, name, role",
      [email, hash, name || email.split("@")[0]]
    );
    const token = jwt.sign({ id: rows[0].id, email: rows[0].email, role: rows[0].role }, process.env.JWT_SECRET || "secret", { expiresIn: "30d" });
    res.status(201).json({ token, user: rows[0] });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// POST /api/auth/login
app.post("/api/auth/login", async (req, res) => {
  const { email, password } = req.body;
  try {
    const { rows } = await db.query("SELECT * FROM users WHERE email = $1", [email]);
    if (!rows.length) return res.status(401).json({ error: "Invalid credentials" });
    const match = await bcrypt.compare(password, rows[0].password_hash);
    if (!match) return res.status(401).json({ error: "Invalid credentials" });
    const token = jwt.sign({ id: rows[0].id, email: rows[0].email, role: rows[0].role }, process.env.JWT_SECRET || "secret", { expiresIn: "30d" });
    res.json({ token, user: { id: rows[0].id, email: rows[0].email, name: rows[0].name, role: rows[0].role } });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ─────────────────────────────────────────────────────────────────────────────
// USER PREFERENCES (authenticated)
// ─────────────────────────────────────────────────────────────────────────────

// GET /api/user/favorites
app.get("/api/user/favorites", authMiddleware, async (req, res) => {
  try {
    const { rows } = await db.query(
      "SELECT c.* FROM favorites f JOIN channels c ON f.channel_id = c.id WHERE f.user_id = $1 ORDER BY f.created_at DESC",
      [req.user.id]
    );
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// POST /api/user/favorites/:channelId
app.post("/api/user/favorites/:channelId", authMiddleware, async (req, res) => {
  try {
    await db.query("INSERT INTO favorites (user_id, channel_id) VALUES ($1, $2) ON CONFLICT DO NOTHING", [req.user.id, req.params.channelId]);
    res.json({ ok: true });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// DELETE /api/user/favorites/:channelId
app.delete("/api/user/favorites/:channelId", authMiddleware, async (req, res) => {
  try {
    await db.query("DELETE FROM favorites WHERE user_id = $1 AND channel_id = $2", [req.user.id, req.params.channelId]);
    res.json({ ok: true });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET /api/user/recent
app.get("/api/user/recent", authMiddleware, async (req, res) => {
  try {
    const { rows } = await db.query(
      "SELECT c.*, rw.watched_at FROM recently_watched rw JOIN channels c ON rw.channel_id = c.id WHERE rw.user_id = $1 ORDER BY rw.watched_at DESC LIMIT 20",
      [req.user.id]
    );
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// POST /api/user/recent/:channelId
app.post("/api/user/recent/:channelId", authMiddleware, async (req, res) => {
  try {
    await db.query(
      "INSERT INTO recently_watched (user_id, channel_id) VALUES ($1, $2) ON CONFLICT (user_id, channel_id) DO UPDATE SET watched_at = NOW()",
      [req.user.id, req.params.channelId]
    );
    // Keep only last 20
    await db.query(
      "DELETE FROM recently_watched WHERE user_id = $1 AND channel_id NOT IN (SELECT channel_id FROM recently_watched WHERE user_id = $1 ORDER BY watched_at DESC LIMIT 20)",
      [req.user.id]
    );
    res.json({ ok: true });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ─────────────────────────────────────────────────────────────────────────────
// ADMIN ROUTES
// ─────────────────────────────────────────────────────────────────────────────

// POST /api/admin/refresh — manually trigger playlist refresh
app.post("/api/admin/refresh", adminMiddleware, async (req, res) => {
  try {
    const result = await refreshPlaylist();
    res.json(result);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET /api/admin/health-check — trigger stream health checks
app.post("/api/admin/health-check", adminMiddleware, async (req, res) => {
  const { limit = 50 } = req.body;
  try {
    const { rows } = await db.query(
      "SELECT id, url FROM channels WHERE status = 'unknown' OR last_checked < NOW() - INTERVAL '6 hours' LIMIT $1",
      [limit]
    );
    const results = await Promise.allSettled(rows.map(ch => checkStreamHealth(ch.url).then(alive => {
      return db.query("UPDATE channels SET status = $1, last_checked = NOW() WHERE id = $2", [alive ? "live" : "offline", ch.id]);
    })));
    cache.flushAll();
    res.json({ checked: rows.length, results: results.filter(r => r.status === "fulfilled").length });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET /api/admin/updates — playlist update history
app.get("/api/admin/updates", adminMiddleware, async (req, res) => {
  try {
    const { rows } = await db.query("SELECT * FROM playlist_updates ORDER BY updated_at DESC LIMIT 20");
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ─────────────────────────────────────────────────────────────────────────────
// PLAYLIST REFRESH LOGIC
// ─────────────────────────────────────────────────────────────────────────────
const M3U_URL = "https://iptv-org.github.io/iptv/index.m3u";

async function refreshPlaylist() {
  console.log("[Playlist] Refreshing from", M3U_URL);
  const start = Date.now();

  const response = await axios.get(M3U_URL, {
    timeout: 30000,
    headers: { "User-Agent": "StreamVault/1.0" }
  });

  const channels = parseM3U(response.data);
  console.log(`[Playlist] Parsed ${channels.length} channels`);

  // Upsert all channels
  const client = await db.connect();
  try {
    await client.query("BEGIN");
    let inserted = 0, updated = 0;

    for (const ch of channels) {
      const result = await client.query(
        `INSERT INTO channels (tvg_id, name, logo_url, language, country, group_title, stream_url, status)
         VALUES ($1, $2, $3, $4, $5, $6, $7, 'unknown')
         ON CONFLICT (stream_url) DO UPDATE SET
           name = EXCLUDED.name,
           logo_url = EXCLUDED.logo_url,
           language = EXCLUDED.language,
           country = EXCLUDED.country,
           group_title = EXCLUDED.group_title,
           updated_at = NOW()
         RETURNING (xmax = 0) AS inserted`,
        [ch.tvgId, ch.name, ch.logo, ch.language, ch.country, ch.group, ch.url]
      );
      if (result.rows[0]?.inserted) inserted++;
      else updated++;
    }

    await client.query(
      "INSERT INTO playlist_updates (channel_count, inserted, updated, duration_ms) VALUES ($1, $2, $3, $4)",
      [channels.length, inserted, updated, Date.now() - start]
    );

    await client.query("COMMIT");
    cache.flushAll();
    return { total: channels.length, inserted, updated, durationMs: Date.now() - start };
  } catch (err) {
    await client.query("ROLLBACK");
    throw err;
  } finally {
    client.release();
  }
}

// ─── Scheduled Jobs ──────────────────────────────────────────────────────────

// Refresh playlist every 6 hours
cron.schedule("0 */6 * * *", async () => {
  try { await refreshPlaylist(); console.log("[Cron] Playlist refreshed"); }
  catch (e) { console.error("[Cron] Refresh failed:", e.message); }
});

// Health-check unknown channels every hour (batch of 100)
cron.schedule("0 * * * *", async () => {
  try {
    const { rows } = await db.query("SELECT id, stream_url as url FROM channels WHERE status = 'unknown' LIMIT 100");
    await Promise.allSettled(rows.map(ch =>
      checkStreamHealth(ch.url).then(alive =>
        db.query("UPDATE channels SET status = $1, last_checked = NOW() WHERE id = $2", [alive ? "live" : "offline", ch.id])
      )
    ));
    cache.del("stats");
    console.log(`[Cron] Health-checked ${rows.length} channels`);
  } catch (e) { console.error("[Cron] Health-check failed:", e.message); }
});

// ─── Health endpoint ──────────────────────────────────────────────────────────
app.get("/health", (req, res) => res.json({ status: "ok", ts: new Date() }));

// ─── Start ────────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 4000;
app.listen(PORT, async () => {
  console.log(`[Server] Running on :${PORT}`);
  try {
    await db.query("SELECT 1");
    console.log("[DB] Connected");
    // Initial load if empty
    const { rows } = await db.query("SELECT COUNT(*) FROM channels");
    if (parseInt(rows[0].count) === 0) {
      console.log("[Init] Empty DB, loading playlist...");
      await refreshPlaylist();
    }
  } catch (e) {
    console.error("[DB] Connection failed:", e.message);
  }
});

module.exports = app;
