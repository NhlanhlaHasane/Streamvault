// server/utils/playlist.js — M3U Parser + Stream Health Checker

const https = require("https");
const http = require("http");
const { URL } = require("url");

/**
 * Parse an M3U Extended playlist string into channel objects.
 * @param {string} text
 * @returns {Array<Object>}
 */
function parseM3U(text) {
  const lines = text.split("\n");
  const channels = [];
  let current = null;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();

    if (line.startsWith("#EXTINF:")) {
      const extract = (key) => {
        const match = line.match(new RegExp(`${key}="([^"]*)"`));
        return match ? match[1].trim() : "";
      };
      const nameMatch = line.match(/,(.+)$/);
      current = {
        tvgId: extract("tvg-id"),
        name: nameMatch ? nameMatch[1].trim() : extract("tvg-name") || "Unknown",
        logo: extract("tvg-logo"),
        language: extract("tvg-language"),
        country: extract("tvg-country"),
        group: extract("group-title") || "General",
        url: "",
      };
    } else if (line && !line.startsWith("#") && current) {
      current.url = line;
      if (isValidUrl(current.url)) {
        channels.push(current);
      }
      current = null;
    }
  }

  return channels;
}

function isValidUrl(str) {
  try {
    const url = new URL(str);
    return url.protocol === "http:" || url.protocol === "https:";
  } catch {
    return false;
  }
}

/**
 * Check if a stream URL is reachable with a HEAD request (timeout 5s).
 * Returns true if alive, false otherwise.
 * @param {string} url
 * @returns {Promise<boolean>}
 */
function checkStreamHealth(url) {
  return new Promise((resolve) => {
    try {
      const parsed = new URL(url);
      const lib = parsed.protocol === "https:" ? https : http;

      const req = lib.request(
        { hostname: parsed.hostname, port: parsed.port, path: parsed.pathname + parsed.search, method: "HEAD", timeout: 5000,
          headers: { "User-Agent": "StreamVault/1.0 HealthChecker" } },
        (res) => {
          req.destroy();
          resolve(res.statusCode >= 200 && res.statusCode < 400);
        }
      );

      req.on("error", () => resolve(false));
      req.on("timeout", () => { req.destroy(); resolve(false); });
      req.end();
    } catch {
      resolve(false);
    }
  });
}

/**
 * Batch health-check channels with concurrency control.
 * @param {Array<{id: string, url: string}>} channels
 * @param {number} concurrency
 * @returns {Promise<Map<string, boolean>>}
 */
async function batchHealthCheck(channels, concurrency = 20) {
  const results = new Map();
  const chunks = [];

  for (let i = 0; i < channels.length; i += concurrency) {
    chunks.push(channels.slice(i, i + concurrency));
  }

  for (const chunk of chunks) {
    const chunkResults = await Promise.allSettled(
      chunk.map(ch => checkStreamHealth(ch.url).then(alive => ({ id: ch.id, alive })))
    );
    for (const r of chunkResults) {
      if (r.status === "fulfilled") {
        results.set(r.value.id, r.value.alive);
      }
    }
  }

  return results;
}

module.exports = { parseM3U, checkStreamHealth, batchHealthCheck, isValidUrl };
